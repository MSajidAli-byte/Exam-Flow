
def slow_logic():
    # Simple code produced while student is looking away
    x = 10
    y = 20
    return x + y
