
def complex_math(n):
    # Student is slow, pondering, looking around
    if n < 2: return n
    return complex_math(n-1) + complex_math(n-2)
