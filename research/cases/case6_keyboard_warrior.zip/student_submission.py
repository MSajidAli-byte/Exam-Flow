
def gibberish():
    a = 1
    b = 2
    # Frantic typing but logic is circular or broken
    while a == a:
        a = b
        b = a
        if a == b: break
